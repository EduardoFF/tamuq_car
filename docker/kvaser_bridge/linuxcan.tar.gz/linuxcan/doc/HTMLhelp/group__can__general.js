var group__can__general =
[
    [ "canGetChannelData", "group__can__general.html#gab9552d1a588b0dbc144b097acba017b2", null ],
    [ "canGetErrorText", "group__can__general.html#ga01a7a415c95c579750bcdd95a1d245c4", null ],
    [ "canGetNumberOfChannels", "group__can__general.html#ga65169ca633cd30aa92b8a80e28a5378b", null ],
    [ "canGetVersion", "group__can__general.html#gafb5688859c56ecb6f8d85705d3ec2f14", null ],
    [ "canGetVersionEx", "group__can__general.html#ga0803bc56e8695150563a48df2c14db5f", null ],
    [ "canInitializeLibrary", "group__can__general.html#gaff1ec1d3416d3bdd56336a7b9ac008b1", null ],
    [ "canIoCtl", "group__can__general.html#gaeaa24db97af22478ca51d48636c7bb12", null ],
    [ "canUnloadLibrary", "group__can__general.html#ga0d1c0e54ea20c3e3b328a32eb10c7b47", null ],
    [ "kvDeviceGetMode", "group__can__general.html#ga2f80c456dd1653ffe8a9062de3e1ad76", null ],
    [ "kvDeviceSetMode", "group__can__general.html#ga8ec3c64b63e50ff210294001bdbad7c3", null ],
    [ "kvFlashLeds", "group__can__general.html#gad3d0fc1bf752047f6e24020c478aeffd", null ],
    [ "kvGetSupportedInterfaceInfo", "group__can__general.html#ga76cb21c1b104f9b679caa3f4cda7424d", null ],
    [ "kvReadDeviceCustomerData", "group__can__general.html#ga4a754a72cb9497994b6bc9133ee62282", null ],
    [ "kvReadTimer", "group__can__general.html#ga0671078a6184ab2b73287946a49763f2", null ],
    [ "kvReadTimer64", "group__can__general.html#gafa060c0f78d459498d1f6236e2d0b5ae", null ],
    [ "kvSetNotifyCallback", "group__can__general.html#ga99976c5b8e2c534b27bf9ec2e715d8d3", null ]
];