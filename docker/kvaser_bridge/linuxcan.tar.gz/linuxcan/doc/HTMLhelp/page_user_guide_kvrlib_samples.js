var page_user_guide_kvrlib_samples =
[
    [ "Configure Remote Device", "page_example_c_kvrconfig.html", null ],
    [ "Connect to Remote Device", "page_example_c_kvrconnect.html", null ],
    [ "Connection Quality Monitor", "page_example_c_kvrnetworkconnectiontest.html", null ]
];