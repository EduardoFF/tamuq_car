var page_user_guide_kvadblib_samples =
[
    [ "Using CAN databases", "page_example_c_candb.html", null ],
    [ "Send database signal", "page_example_c_gensig.html", null ]
];